using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Dapper;

namespace Eval.Models
{
    public static class BD
    {
        private static string _connectionString = @"Server=.; DataBase=BDEmpresa;Trusted_Connection=True;";

        public static List<Cliente> GetClientes()
        {
            List<Cliente> Lista = null;
            string SQL = "SELECT * FROM Clientes"; 
            using(SqlConnection db = new SqlConnection(_connectionString))
            {
                Lista = db.Query<Cliente>(SQL).ToList(); 
            } 
            return Lista;
        }
        public static Cliente GetClienteById(int Id)
        {
            Cliente item = null;
            string SQL = "SELECT * FROM Clientes C INNER JOIN Provincias P ON C.IdProvincia=P.IdProvincia"; 
            SQL +=" WHERE IdCliente=@pId"; 

            using(SqlConnection db = new SqlConnection(_connectionString))
            {
                item = db.QueryFirstOrDefault<Cliente>(SQL, new { pId = Id }); 
            } 
            return item;
        }
        public static bool GetClienteByCUIT(string cuit)
        {
            Cliente item = null;
            string SQL = "SELECT * FROM Clientes WHERE CUIT=@pCUIT"; 

            using(SqlConnection db = new SqlConnection(_connectionString))
            {
                item = db.QueryFirstOrDefault<Cliente>(SQL, new { pCUIT = cuit }); 
            } 
            return (item!=null);
        }
        public static void DeleteClienteById(int Id)
        {
            string SQL = "DELETE FROM Clientes WHERE IdCliente=@pId"; 
            using(SqlConnection db = new SqlConnection(_connectionString))
            {
                db.Execute(SQL, new { pId = Id }); 
            } 
        }
        public static List<Provincia> GetProvincias()
        {
            List<Provincia> Lista = null;
            string SQL = "SELECT * FROM Provincias"; 
            using(SqlConnection db = new SqlConnection(_connectionString))
            {
                Lista = db.Query<Provincia>(SQL).ToList(); 
            } 
            return Lista;
        }
        public static void InsertCliente(Cliente item)
        {
            string SQL = "INSERT INTO Clientes(NombreCliente, CUIT, FotoCliente, FechaUltimaCompra, IdProvincia)";
            SQL += " VALUES (@pNombreCliente, @pCUIT, @pFotoCliente, @pFechaUltimaCompra, @pIdProvincia)"; 
            using(SqlConnection db = new SqlConnection(_connectionString))
            {
                db.Execute(SQL, new {
                    pNombreCliente = item.NombreCliente,
                    pCUIT = item.CUIT,
                    pFotoCliente = item.FotoCliente,
                    pFechaUltimaCompra = item.FechaUltimaCompra,
                    pIdProvincia = item.IdProvincia
                }); 
            }   
        }
    }
}