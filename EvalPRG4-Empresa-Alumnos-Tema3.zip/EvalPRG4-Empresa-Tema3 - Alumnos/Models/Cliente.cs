using System;
namespace Eval.Models
{
    public class Cliente
    {
        public int IdCliente { get; set;}
        public string NombreCliente { get; set;}
        public string CUIT{ get; set;}
        public string FotoCliente { get; set;}
        public int IdProvincia { get; set;}
        public string NombreProvincia { get; set;}
        public DateTime FechaUltimaCompra { get; set;}          
    }
}