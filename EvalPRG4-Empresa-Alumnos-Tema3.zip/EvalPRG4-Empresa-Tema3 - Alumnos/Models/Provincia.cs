namespace Eval.Models
{
    public class Provincia
    {
        public int IdProvincia { get; set;}
        public string NombreProvincia { get; set;}
        public string Pais { get; set;}
        
    }
}